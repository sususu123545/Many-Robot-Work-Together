# 节拍资料包 · 2026-11-23

供核对脚本设定与动作顺序。**不含时间戳数据**——那份记录从未采集过。

## 内容

| 文件 | 说明 | sha256 |
| --- | --- | --- |
| `执行节拍-能提供与不能提供的.md` | 节拍说明：为什么没有时间戳，以及源码可查的节拍边界 | `98553bffa740f230dfb61cec5b1ebcc1` |
| `grasp_sequence.py` | 提交 9b5c092 的版本，与当前工作区 sha256 完全一致（已核验） | `69476afb0c210cea751d7eba3a603188` |
| `run3_commands.jsonl` | 从控制台日志结构化的 56 条关节指令，timestamp 恒为 null | `8ea60f6bcaec91cf64f3d4abc578576f` |
| `capture_cadence.py` | 采集工具；listen 只订阅不发布，pause 空载可跑 | `33b5e8b24fc3b0e499c88ef2e7dada8f` |
| `test_capture_cadence.py` | 14 项测试 | `93f77303c7420b81d931153e63809be9` |
| `run3_console.log` | 11-23 成功那次的完整控制台输出（原文，无时间戳） | `680dbe8c62f4b60bd730e7f4abc8a6d3` |

## 脚本版本核验

- 提交：`9b5c0921a2ded53dfee9b6efe2ec13de1396c087`
- 提交时间：2026-11-23 16:53:24 +0800
- 提交说明：`fix(grasp): 下降步长按剩余高度收紧，新场地首抓成功`
- `grasp_sequence.py` 与仓库当前 `tools/grasp_sequence.py` **sha256 完全一致**，
  且工作区无未提交改动 → 包里这份就是当时运行的版本。

## 启动参数

**没有留档。** 只能从日志反推：

- `--plane -0.094`（日志首行 `plane z=-0.094 m`）
- `--vision ground`（日志有 ground estimator，是默认值）
- **未使用** `--approach-chassis`（日志 `chassis stays put`）
- `--open-tick` / `--close-limit` / `--lift` / `--dz` **无法确认**
