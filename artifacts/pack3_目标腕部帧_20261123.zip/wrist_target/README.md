# 目标腕部帧（同姿态像素对比用）

回应「优先发 grasp_approach_recheck_20261123T062942Z 中 SHA-256 以 0b469715b181 开头的那张」。

## 目标帧

| 项 | 值 |
| --- | --- |
| 文件 | `target_frame/frame_1.jpg`（**原始字节，未重新编码**） |
| sha256 | `0b469715b18140d9634284de3caa39a2247b9643419cd780617881a8e4ae7cee` |
| 尺寸 / 格式 | 640 × 480 / JPEG / RGB |
| EXIF 方向标记 | 无（原方向） |
| image_stamp_ns | `1795415352527473934` |
| 六轴 tick | `{"joint1": 484, "joint2": 687, "joint3": 927, "joint4": 206, "joint5": 499, "r_joint": 247}` |
| 图像↔关节偏差 | header 9.560 ms / receiver 4.143 ms |

`arm_base → rear_camera` 的 TF 见 `target_frame/pairing.json`。

## 为什么上一包里的图配不上

pack1 里那张是 `latest.jpg`（sha256 `55354725f4d7acca…`），它恰好是这 11 张里
**唯一没有六轴读数、也没有 TF** 的一张。选帧失误，这里补上正确的。

## 另外 9 张也已配对

`paired_frames/` 里放了同一回合另外 9 张能配上六轴的原始 JPEG，
对应关系在 `paired_frames/pairs.json`。如果目标帧的画面不理想（夹指被裁、
红球不在画面里），可以从这 9 张里换一帧。

全部 10 张都是同一静止姿态（该回合未发送任何运动指令，
`robot_commands_sent = 0`），关节读数一致，所以任一张都能做同姿态对比；
差别只在取景瞬间的画面细节。

## 相机内参（同一回合采集）

```json
{
  "width": 640,
  "height": 480,
  "distortion_model": "equidistant",
  "k": [
    541.286233208,
    0.0,
    308.972422909,
    0.0,
    536.831652047,
    220.80791832,
    0.0,
    0.0,
    1.0
  ],
  "d": [
    -0.173265335147,
    0.276973718043,
    -1.97373104458,
    3.56886883326
  ],
  "camera_frame": "rear_camera"
}
```
